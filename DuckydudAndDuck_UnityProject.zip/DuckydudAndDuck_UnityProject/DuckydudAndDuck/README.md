# Duckydud & Duck — Unity Project

A colorful 3D obstacle-course platformer starring Ducky (and rival/companion Duck),
built with Unity + C#, using the supplied KayKit Mini-Game Variety Pack models and
Bit by Bit font.

## Start here

Read **`SETUP_GUIDE.md`** first — it walks through opening this in Unity, wiring the
scripts to scenes (the one step that has to happen in the Editor, not from code), and
building both a Windows `.exe` and a browser build for itch.io.

## What's included

```
Assets/
  Scripts/
    Player/          PlayerController.cs, InputRemapHelper.cs
    Camera/           CameraFollow.cs
    Platforms/        MovingPlatform.cs, RotatingPlatform.cs, FallingPlatform.cs,
                       PlatformPassenger.cs
    Gameplay/         BouncePad.cs, HazardObstacle.cs, Checkpoint.cs, Collectible.cs,
                       FinishLine.cs, KillZone.cs
    Managers/         GameManager.cs (persistent progress/save), LevelManager.cs
                       (per-level state)
    UI/               UIManager.cs, MainMenuController.cs, LevelSelectButton.cs,
                       LoadingScreen.cs
    Audio/            MusicManager.cs
  Art/
    Fonts/            BitByBit.ttf (your uploaded font)
    Models/KayKit/    Your uploaded KayKit Mini-Game Variety Pack models + license
  Scenes/             (empty — you'll create MainMenu + 6 level scenes per the guide)
```

## Design notes for whoever builds this out in-Editor

- All physics is `CharacterController`-based (not Rigidbody player physics), which is
  the standard, most reliable approach for platformer controllers in Unity — it avoids
  the jitter/bounciness Rigidbody players tend to get on moving platforms and slopes.
- Moving/rotating platforms carry the player via an explicit passenger-tracking
  handshake (`PlatformPassenger.cs`) rather than parenting the player transform, which
  avoids scale/rotation side-effects on the CharacterController.
- Save data (unlocked levels, best times, total feathers, volume settings) uses
  `PlayerPrefs`, which works correctly in both the Windows build and the WebGL/itch.io
  build (WebGL PlayerPrefs persists via browser local storage).
- Six level scene names are pre-registered in `GameManager.levelSceneNames` matching
  the brief's level list (Duck Dash → Final Flight) — rename/reorder there if you
  change the lineup.
