using System.Collections.Generic;
using UnityEngine;

namespace DuckydudAndDuck.Managers
{
    /// <summary>
    /// Lives in each level scene (not persistent). Tracks respawn point,
    /// collectibles found this run, elapsed time, and drives the UIManager
    /// for pause/level-complete screens. Index this level's position in
    /// GameManager.levelSceneNames via levelIndex.
    /// </summary>
    public class LevelManager : MonoBehaviour
    {
        public static LevelManager Instance { get; private set; }

        [Header("Level Identity")]
        public int levelIndex;
        public int totalCollectiblesInLevel = 10;

        [Header("References")]
        public Transform playerSpawnPoint;
        public DuckydudAndDuck.Player.PlayerController player;
        public UI.UIManager uiManager;

        public int CollectiblesFound { get; private set; }
        public float ElapsedTime { get; private set; }
        public bool LevelComplete { get; private set; }
        public bool IsPaused { get; private set; }

        private Gameplay.Checkpoint _activeCheckpoint;

        private void Awake()
        {
            Instance = this;
        }

        private void Start()
        {
            if (player != null && playerSpawnPoint != null)
                player.Teleport(playerSpawnPoint.position, playerSpawnPoint.rotation);

            uiManager?.ShowHUD();
            uiManager?.UpdateCollectibleCounter(CollectiblesFound, totalCollectiblesInLevel);
            Time.timeScale = 1f;
        }

        private void Update()
        {
            if (!LevelComplete && !IsPaused)
                ElapsedTime += Time.deltaTime;

            if (Input.GetKeyDown(KeyCode.Escape) && !LevelComplete)
                TogglePause();

            uiManager?.UpdateTimer(ElapsedTime);
        }

        public void RegisterCheckpoint(Gameplay.Checkpoint checkpoint)
        {
            _activeCheckpoint = checkpoint;
        }

        public void RespawnAtCheckpoint()
        {
            Vector3 pos = _activeCheckpoint != null ? _activeCheckpoint.respawnPoint.position : playerSpawnPoint.position;
            Quaternion rot = _activeCheckpoint != null ? _activeCheckpoint.respawnPoint.rotation : playerSpawnPoint.rotation;
            player.Teleport(pos, rot);
        }

        public void CollectItem(Gameplay.Collectible item)
        {
            CollectiblesFound++;
            GameManager.Instance?.AddFeathers(item.scoreValue > 0 ? 1 : 0);
            uiManager?.UpdateCollectibleCounter(CollectiblesFound, totalCollectiblesInLevel);
        }

        public void CompleteLevel()
        {
            if (LevelComplete) return;
            LevelComplete = true;

            GameManager.Instance?.UnlockNextLevel(levelIndex);
            GameManager.Instance?.ReportLevelScore(levelIndex, CollectiblesFound, ElapsedTime);

            uiManager?.ShowLevelComplete(ElapsedTime, CollectiblesFound, totalCollectiblesInLevel);
        }

        public void TogglePause()
        {
            IsPaused = !IsPaused;
            Time.timeScale = IsPaused ? 0f : 1f;
            if (IsPaused) uiManager?.ShowPauseMenu();
            else uiManager?.HidePauseMenu();
        }

        /// <summary>Called by a "fall off the world" trigger volume placed under each level.</summary>
        public void OnPlayerFellOff()
        {
            RespawnAtCheckpoint();
        }
    }
}
