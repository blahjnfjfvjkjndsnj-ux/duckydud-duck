using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DuckydudAndDuck.Managers
{
    /// <summary>
    /// Persists across scenes (DontDestroyOnLoad). Tracks unlocked levels,
    /// total feathers collected, per-level best scores, and settings.
    /// Uses PlayerPrefs so progress saves correctly in the WebGL/itch.io build too.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("Level List (must match Build Settings scene order)")]
        public string[] levelSceneNames = {
            "Level01_DuckDash",
            "Level02_WackyWarehouse",
            "Level03_SkyDuck",
            "Level04_TopsyTurvyFactory",
            "Level05_DuckArena",
            "Level06_FinalFlight"
        };

        public int TotalFeathers { get; private set; }
        public int UnlockedLevelCount { get; private set; } = 1;

        private const string KeyTotalFeathers = "DD_TotalFeathers";
        private const string KeyUnlockedLevels = "DD_UnlockedLevels";
        private const string KeyBestScorePrefix = "DD_BestScore_";
        private const string KeySfxVolume = "DD_SfxVolume";
        private const string KeyMusicVolume = "DD_MusicVolume";

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            LoadProgress();
        }

        private void LoadProgress()
        {
            TotalFeathers = PlayerPrefs.GetInt(KeyTotalFeathers, 0);
            UnlockedLevelCount = Mathf.Max(1, PlayerPrefs.GetInt(KeyUnlockedLevels, 1));
        }

        public void AddFeathers(int amount)
        {
            TotalFeathers += amount;
            PlayerPrefs.SetInt(KeyTotalFeathers, TotalFeathers);
            PlayerPrefs.Save();
        }

        public bool IsLevelUnlocked(int levelIndex) => levelIndex < UnlockedLevelCount;

        public void UnlockNextLevel(int completedLevelIndex)
        {
            int nextUnlocked = Mathf.Min(levelSceneNames.Length, completedLevelIndex + 2);
            if (nextUnlocked > UnlockedLevelCount)
            {
                UnlockedLevelCount = nextUnlocked;
                PlayerPrefs.SetInt(KeyUnlockedLevels, UnlockedLevelCount);
                PlayerPrefs.Save();
            }
        }

        public void ReportLevelScore(int levelIndex, int collectiblesFound, float timeSeconds)
        {
            string key = KeyBestScorePrefix + levelIndex;
            float bestTime = PlayerPrefs.GetFloat(key, float.MaxValue);
            if (timeSeconds < bestTime)
            {
                PlayerPrefs.SetFloat(key, timeSeconds);
                PlayerPrefs.Save();
            }
        }

        public float GetBestTime(int levelIndex)
        {
            return PlayerPrefs.GetFloat(KeyBestScorePrefix + levelIndex, -1f);
        }

        public void LoadLevel(int levelIndex)
        {
            if (levelIndex < 0 || levelIndex >= levelSceneNames.Length) return;
            SceneManager.LoadScene(levelSceneNames[levelIndex]);
        }

        public void LoadMainMenu()
        {
            SceneManager.LoadScene("MainMenu");
        }

        public void ReloadCurrentLevel()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        public void QuitGame()
        {
            // Quit is ignored automatically by Unity in WebGL builds; harmless to leave in
            // for the standalone Windows build.
            Application.Quit();
        }

        // --- Settings ---
        public float SfxVolume
        {
            get => PlayerPrefs.GetFloat(KeySfxVolume, 1f);
            set { PlayerPrefs.SetFloat(KeySfxVolume, value); PlayerPrefs.Save(); }
        }

        public float MusicVolume
        {
            get => PlayerPrefs.GetFloat(KeyMusicVolume, 0.7f);
            set { PlayerPrefs.SetFloat(KeyMusicVolume, value); PlayerPrefs.Save(); }
        }
    }
}
