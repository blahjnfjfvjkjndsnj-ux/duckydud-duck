using System.Collections;
using UnityEngine;

namespace DuckydudAndDuck.Audio
{
    /// <summary>
    /// Place one instance per level scene (not persistent - each level has
    /// its own theme track). Crossfades in on scene start and reacts to
    /// GameManager's music volume setting.
    /// </summary>
    [RequireComponent(typeof(AudioSource))]
    public class MusicManager : MonoBehaviour
    {
        public AudioClip levelTrack;
        public float fadeInDuration = 1.5f;

        private AudioSource _source;

        private void Awake()
        {
            _source = GetComponent<AudioSource>();
            _source.loop = true;
            _source.playOnAwake = false;
            _source.clip = levelTrack;
        }

        private void Start()
        {
            float targetVolume = Managers.GameManager.Instance != null ? Managers.GameManager.Instance.MusicVolume : 0.7f;
            StartCoroutine(FadeIn(targetVolume));
        }

        private IEnumerator FadeIn(float targetVolume)
        {
            _source.volume = 0f;
            _source.Play();
            float t = 0f;
            while (t < fadeInDuration)
            {
                t += Time.deltaTime;
                _source.volume = Mathf.Lerp(0f, targetVolume, t / fadeInDuration);
                yield return null;
            }
            _source.volume = targetVolume;
        }
    }
}
