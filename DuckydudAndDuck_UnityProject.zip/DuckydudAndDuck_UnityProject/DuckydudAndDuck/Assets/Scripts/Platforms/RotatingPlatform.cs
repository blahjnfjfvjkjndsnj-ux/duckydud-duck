using UnityEngine;

namespace DuckydudAndDuck.Platforms
{
    /// <summary>
    /// Continuously rotates around a chosen axis. Used both for rotating
    /// platforms you stand on (parent the player transform temporarily via
    /// PlatformPassenger) and for spinning obstacles (set isObstacle = true
    /// to also apply knockback on contact).
    /// </summary>
    [RequireComponent(typeof(PlatformPassenger))]
    public class RotatingPlatform : MonoBehaviour
    {
        public Vector3 rotationAxis = Vector3.up;
        public float degreesPerSecond = 45f;
        public bool isObstacle = false;
        public float knockbackForce = 12f;

        private Quaternion _lastRotation;
        private PlatformPassenger _passenger;

        private void Awake()
        {
            _passenger = GetComponent<PlatformPassenger>();
            _lastRotation = transform.rotation;
        }

        private void Update()
        {
            transform.Rotate(rotationAxis.normalized, degreesPerSecond * Time.deltaTime, Space.World);

            if (_passenger.IsCurrentlyStoodOn() && _passenger.CurrentPassenger != null)
            {
                // Carry the passenger around with the rotation delta.
                Quaternion deltaRot = transform.rotation * Quaternion.Inverse(_lastRotation);
                Vector3 playerPos = _passenger.CurrentPassenger.transform.position;
                Vector3 offset = playerPos - transform.position;
                Vector3 newOffset = deltaRot * offset;
                Vector3 moveDelta = (transform.position + newOffset) - playerPos;
                _passenger.CurrentPassenger.GetComponent<CharacterController>().Move(moveDelta);
            }
            _lastRotation = transform.rotation;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!isObstacle) return;
            if (other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController player))
            {
                Vector3 dir = (other.transform.position - transform.position);
                dir.y = 0f;
                player.ApplyKnockback(dir.normalized, knockbackForce);
            }
        }
    }
}
