using System.Collections;
using UnityEngine;

namespace DuckydudAndDuck.Platforms
{
    /// <summary>
    /// Shakes then drops away shortly after the player steps on it, and
    /// respawns after a delay. Requires a trigger-less collider (the platform
    /// itself) plus a child trigger volume assigned to triggerZone, OR simply
    /// use the CharacterController's OnControllerColliderHit via PlatformPassenger.
    /// </summary>
    [RequireComponent(typeof(PlatformPassenger))]
    public class FallingPlatform : MonoBehaviour
    {
        public float shakeDelay = 0.6f;
        public float shakeDuration = 0.5f;
        public float shakeMagnitude = 0.06f;
        public float respawnDelay = 3f;
        public bool respawns = true;

        private Vector3 _originalPosition;
        private Rigidbody _rb;
        private Collider _collider;
        private MeshRenderer[] _renderers;
        private PlatformPassenger _passenger;
        private bool _triggered;

        private void Awake()
        {
            _originalPosition = transform.position;
            _rb = GetComponent<Rigidbody>();
            _collider = GetComponent<Collider>();
            _renderers = GetComponentsInChildren<MeshRenderer>();
            _passenger = GetComponent<PlatformPassenger>();

            if (_rb == null) _rb = gameObject.AddComponent<Rigidbody>();
            _rb.isKinematic = true;
        }

        private void Update()
        {
            if (!_triggered && _passenger.IsCurrentlyStoodOn())
            {
                _triggered = true;
                StartCoroutine(FallSequence());
            }
        }

        private IEnumerator FallSequence()
        {
            yield return new WaitForSeconds(shakeDelay);

            float t = 0f;
            while (t < shakeDuration)
            {
                t += Time.deltaTime;
                Vector3 offset = Random.insideUnitSphere * shakeMagnitude;
                offset.y = Mathf.Abs(offset.y) * 0.3f;
                transform.position = _originalPosition + offset;
                yield return null;
            }
            transform.position = _originalPosition;

            _rb.isKinematic = false;
            _rb.useGravity = true;

            if (respawns)
            {
                yield return new WaitForSeconds(respawnDelay);
                _rb.linearVelocity = Vector3.zero;
                _rb.angularVelocity = Vector3.zero;
                _rb.isKinematic = true;
                transform.position = _originalPosition;
                transform.rotation = Quaternion.identity;
                SetVisible(true);
                yield return new WaitForSeconds(0.3f);
                _triggered = false;
            }
        }

        private void SetVisible(bool visible)
        {
            foreach (var r in _renderers) r.enabled = visible;
            if (_collider != null) _collider.enabled = visible;
        }
    }
}
