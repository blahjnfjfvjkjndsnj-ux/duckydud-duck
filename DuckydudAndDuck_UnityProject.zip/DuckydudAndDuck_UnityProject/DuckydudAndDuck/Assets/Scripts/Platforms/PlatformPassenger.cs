using UnityEngine;

namespace DuckydudAndDuck.Platforms
{
    /// <summary>
    /// Attach alongside any platform script (MovingPlatform, RotatingPlatform, etc.)
    /// so the player controller can register itself as "standing on" this platform
    /// each frame it touches it. The platform script reads LastStoodOnFrame to know
    /// whether to carry the player this frame.
    /// </summary>
    public class PlatformPassenger : MonoBehaviour
    {
        public int LastStoodOnFrame { get; private set; } = -1;
        public DuckydudAndDuck.Player.PlayerController CurrentPassenger { get; private set; }

        public void NotifyStandingOn(DuckydudAndDuck.Player.PlayerController player)
        {
            LastStoodOnFrame = Time.frameCount;
            CurrentPassenger = player;
        }

        public bool IsCurrentlyStoodOn()
        {
            return LastStoodOnFrame >= Time.frameCount - 1;
        }
    }
}
