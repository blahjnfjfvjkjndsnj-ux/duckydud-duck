using UnityEngine;

namespace DuckydudAndDuck.Platforms
{
    /// <summary>
    /// Moves back and forth (or through a list of waypoints) and carries the
    /// player with it using CharacterController.Move deltas applied via
    /// PlatformPassenger. Requires a PlatformPassenger component on the same object.
    /// </summary>
    [RequireComponent(typeof(PlatformPassenger))]
    public class MovingPlatform : MonoBehaviour
    {
        public enum PathMode { PingPong, Loop }

        [Header("Path")]
        public Transform[] waypoints;
        public PathMode mode = PathMode.PingPong;
        public float speed = 3f;
        public bool startMoving = true;

        [Header("Easing")]
        public bool useEasing = true;
        public float pauseAtEnds = 0.5f;

        private int _currentIndex;
        private int _direction = 1;
        private float _pauseTimer;
        private Vector3 _lastPosition;
        private PlatformPassenger _passenger;

        private void Awake()
        {
            _passenger = GetComponent<PlatformPassenger>();
            _lastPosition = transform.position;
            if (waypoints != null && waypoints.Length > 0)
                transform.position = waypoints[0].position;
        }

        private void Update()
        {
            if (!startMoving || waypoints == null || waypoints.Length < 2)
            {
                _lastPosition = transform.position;
                return;
            }

            if (_pauseTimer > 0f)
            {
                _pauseTimer -= Time.deltaTime;
            }
            else
            {
                Transform targetWp = waypoints[_currentIndex];
                float t = useEasing ? EaseInOutSine(0f, 1f, Mathf.Clamp01(speed * Time.deltaTime)) : speed * Time.deltaTime;
                transform.position = Vector3.MoveTowards(transform.position, targetWp.position, speed * Time.deltaTime);

                if (Vector3.Distance(transform.position, targetWp.position) < 0.02f)
                {
                    _pauseTimer = pauseAtEnds;
                    AdvanceWaypoint();
                }
            }

            // Carry the passenger by applying this frame's delta directly.
            Vector3 delta = transform.position - _lastPosition;
            if (delta.sqrMagnitude > 0.00001f && _passenger.IsCurrentlyStoodOn() && _passenger.CurrentPassenger != null)
            {
                _passenger.CurrentPassenger.GetComponent<CharacterController>().Move(delta);
            }
            _lastPosition = transform.position;
        }

        private void AdvanceWaypoint()
        {
            if (mode == PathMode.Loop)
            {
                _currentIndex = (_currentIndex + 1) % waypoints.Length;
            }
            else // PingPong
            {
                _currentIndex += _direction;
                if (_currentIndex >= waypoints.Length)
                {
                    _currentIndex = waypoints.Length - 2;
                    _direction = -1;
                }
                else if (_currentIndex < 0)
                {
                    _currentIndex = 1;
                    _direction = 1;
                }
            }
        }

        private static float EaseInOutSine(float a, float b, float t)
        {
            float eased = -(Mathf.Cos(Mathf.PI * t) - 1f) / 2f;
            return Mathf.Lerp(a, b, eased);
        }

        private void OnDrawGizmosSelected()
        {
            if (waypoints == null) return;
            Gizmos.color = Color.yellow;
            for (int i = 0; i < waypoints.Length; i++)
            {
                if (waypoints[i] == null) continue;
                Gizmos.DrawWireSphere(waypoints[i].position, 0.3f);
                if (i > 0 && waypoints[i - 1] != null)
                    Gizmos.DrawLine(waypoints[i - 1].position, waypoints[i].position);
            }
        }
    }
}
