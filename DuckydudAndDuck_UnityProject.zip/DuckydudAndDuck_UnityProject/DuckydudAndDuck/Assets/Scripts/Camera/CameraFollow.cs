using UnityEngine;

namespace DuckydudAndDuck.CameraSystem
{
    /// <summary>
    /// Smooth third-person follow camera with collision avoidance (pulls in when
    /// geometry blocks the view), mouse-look orbit, and a simple event-driven
    /// zoom for cinematic moments (checkpoints, finish line, etc).
    /// </summary>
    public class CameraFollow : MonoBehaviour
    {
        [Header("Target")]
        public Transform target;
        public Vector3 targetOffset = new Vector3(0f, 1.4f, 0f);

        [Header("Distance & Angle")]
        public float defaultDistance = 6.5f;
        public float minDistance = 1.2f;
        public float height = 2.2f;
        public float mouseSensitivity = 3f;
        public float pitchMin = -20f;
        public float pitchMax = 60f;

        [Header("Smoothing")]
        public float positionSmoothTime = 0.08f;
        public float rotationSmoothSpeed = 10f;
        public float zoomSmoothSpeed = 6f;

        [Header("Collision")]
        public LayerMask obstructionMask;
        public float cameraRadius = 0.3f;

        private float _yaw;
        private float _pitch = 15f;
        private float _currentDistance;
        private float _targetDistance;
        private Vector3 _velocity;

        private void Start()
        {
            _currentDistance = defaultDistance;
            _targetDistance = defaultDistance;
            if (target != null)
                _yaw = target.eulerAngles.y;

            Cursor.lockState = CursorLockMode.Locked;
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
                Cursor.lockState = Cursor.lockState == CursorLockMode.Locked ? CursorLockMode.None : CursorLockMode.Locked;

            if (Cursor.lockState == CursorLockMode.Locked)
            {
                _yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
                _pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
                _pitch = Mathf.Clamp(_pitch, pitchMin, pitchMax);
            }
        }

        private void LateUpdate()
        {
            if (target == null) return;

            Vector3 focusPoint = target.position + targetOffset;
            Quaternion rotation = Quaternion.Euler(_pitch, _yaw, 0f);

            // Collision check: shrink distance if something is between camera and target
            _targetDistance = defaultDistance;
            Vector3 desiredCamPos = focusPoint - rotation * Vector3.forward * defaultDistance + Vector3.up * height * 0.01f;
            if (Physics.SphereCast(focusPoint, cameraRadius, (desiredCamPos - focusPoint).normalized,
                    out RaycastHit hit, defaultDistance, obstructionMask, QueryTriggerInteraction.Ignore))
            {
                _targetDistance = Mathf.Clamp(hit.distance, minDistance, defaultDistance);
            }

            _currentDistance = Mathf.Lerp(_currentDistance, _targetDistance, zoomSmoothSpeed * Time.deltaTime);

            Vector3 finalPosition = focusPoint - rotation * Vector3.forward * _currentDistance;
            transform.position = Vector3.SmoothDamp(transform.position, finalPosition, ref _velocity, positionSmoothTime);

            Quaternion lookRotation = Quaternion.LookRotation(focusPoint - transform.position, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, rotationSmoothSpeed * Time.deltaTime);
        }

        /// <summary>Call for a quick cinematic punch-in, e.g. on finish line or big collectible.</summary>
        public void CinematicPulse(float closerDistance, float duration)
        {
            StopAllCoroutines();
            StartCoroutine(PulseRoutine(closerDistance, duration));
        }

        private System.Collections.IEnumerator PulseRoutine(float closerDistance, float duration)
        {
            float original = defaultDistance;
            defaultDistance = closerDistance;
            yield return new WaitForSeconds(duration);
            defaultDistance = original;
        }
    }
}
