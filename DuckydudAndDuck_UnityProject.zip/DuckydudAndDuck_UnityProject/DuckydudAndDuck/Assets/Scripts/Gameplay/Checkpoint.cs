using UnityEngine;

namespace DuckydudAndDuck.Gameplay
{
    /// <summary>
    /// Trigger volume that registers itself as the player's respawn point
    /// with the LevelManager, plays a little celebration FX/sound the first
    /// time it's touched, and visually marks itself as "activated".
    /// </summary>
    public class Checkpoint : MonoBehaviour
    {
        public int checkpointIndex;
        public Transform respawnPoint; // usually just above this object
        public ParticleSystem activateFX;
        public AudioSource sfxSource;
        public AudioClip activateClip;
        public GameObject inactiveVisual;
        public GameObject activeVisual;

        private bool _activated;

        private void Awake()
        {
            if (respawnPoint == null) respawnPoint = transform;
            SetVisual(false);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (_activated) return;
            if (!other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController _)) return;

            _activated = true;
            SetVisual(true);

            if (activateFX != null) activateFX.Play();
            if (sfxSource != null && activateClip != null) sfxSource.PlayOneShot(activateClip);

            Managers.LevelManager.Instance?.RegisterCheckpoint(this);
        }

        private void SetVisual(bool active)
        {
            if (inactiveVisual != null) inactiveVisual.SetActive(!active);
            if (activeVisual != null) activeVisual.SetActive(active);
        }
    }
}
