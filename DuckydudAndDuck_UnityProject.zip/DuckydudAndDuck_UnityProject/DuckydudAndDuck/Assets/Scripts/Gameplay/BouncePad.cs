using UnityEngine;

namespace DuckydudAndDuck.Gameplay
{
    /// <summary>
    /// A trigger volume placed above a bouncy surface mesh. Launches the
    /// player upward and plays a squash/stretch + FX + sound.
    /// </summary>
    public class BouncePad : MonoBehaviour
    {
        public float bounceVelocity = 14f;
        public Transform visualMesh; // the mushroom-cap / pad mesh to squash
        public ParticleSystem bounceFX;
        public AudioSource sfxSource;
        public AudioClip bounceClip;

        private Vector3 _originalScale;

        private void Awake()
        {
            if (visualMesh != null) _originalScale = visualMesh.localScale;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController player))
            {
                player.ApplyBounce(bounceVelocity);
                if (bounceFX != null) bounceFX.Play();
                if (sfxSource != null && bounceClip != null) sfxSource.PlayOneShot(bounceClip);
                if (visualMesh != null) StartCoroutine(SquashPad());
            }
        }

        private System.Collections.IEnumerator SquashPad()
        {
            visualMesh.localScale = new Vector3(_originalScale.x * 1.3f, _originalScale.y * 0.5f, _originalScale.z * 1.3f);
            float t = 0f;
            while (t < 0.3f)
            {
                t += Time.deltaTime;
                visualMesh.localScale = Vector3.Lerp(visualMesh.localScale, _originalScale, t / 0.3f);
                yield return null;
            }
            visualMesh.localScale = _originalScale;
        }
    }
}
