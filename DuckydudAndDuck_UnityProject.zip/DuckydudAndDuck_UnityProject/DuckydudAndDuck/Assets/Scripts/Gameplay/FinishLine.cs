using UnityEngine;

namespace DuckydudAndDuck.Gameplay
{
    /// <summary>
    /// Trigger volume at the end of a level. Stops the timer, fires confetti,
    /// and tells the LevelManager to show the completion screen.
    /// </summary>
    public class FinishLine : MonoBehaviour
    {
        public ParticleSystem confettiFX;
        public AudioSource sfxSource;
        public AudioClip finishClip;
        public DuckydudAndDuck.CameraSystem.CameraFollow cinematicCamera;
        public float cinematicZoomDistance = 3.5f;
        public float cinematicDuration = 2.5f;

        private bool _finished;

        private void OnTriggerEnter(Collider other)
        {
            if (_finished) return;
            if (!other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController _)) return;

            _finished = true;
            if (confettiFX != null) confettiFX.Play();
            if (sfxSource != null && finishClip != null) sfxSource.PlayOneShot(finishClip);
            if (cinematicCamera != null) cinematicCamera.CinematicPulse(cinematicZoomDistance, cinematicDuration);

            Managers.LevelManager.Instance?.CompleteLevel();
        }
    }
}
