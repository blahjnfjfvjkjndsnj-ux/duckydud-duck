using UnityEngine;

namespace DuckydudAndDuck.Gameplay
{
    /// <summary>
    /// Place a large flat trigger volume well below each level's lowest
    /// platform. Anything that falls into it respawns at the last checkpoint.
    /// </summary>
    public class KillZone : MonoBehaviour
    {
        private void OnTriggerEnter(Collider other)
        {
            if (other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController _))
            {
                Managers.LevelManager.Instance?.OnPlayerFellOff();
            }
        }
    }
}
