using UnityEngine;

namespace DuckydudAndDuck.Gameplay
{
    /// <summary>
    /// A spinning, bobbing collectible (feather / gem / rubber duck token).
    /// Notifies the LevelManager and plays FX/sound on pickup, then disables itself.
    /// </summary>
    public class Collectible : MonoBehaviour
    {
        public enum CollectibleType { Feather, SecretToken, ScoreGem }

        public CollectibleType type = CollectibleType.Feather;
        public int scoreValue = 10;
        public float spinSpeed = 90f;
        public float bobHeight = 0.25f;
        public float bobSpeed = 2f;
        public ParticleSystem pickupFX;
        public AudioSource sfxSource;
        public AudioClip pickupClip;

        private Vector3 _startPos;
        private bool _collected;

        private void Awake()
        {
            _startPos = transform.position;
        }

        private void Update()
        {
            transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.World);
            float y = Mathf.Sin(Time.time * bobSpeed) * bobHeight;
            transform.position = _startPos + Vector3.up * y;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (_collected) return;
            if (!other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController _)) return;

            _collected = true;
            Managers.LevelManager.Instance?.CollectItem(this);

            if (pickupFX != null)
            {
                var fx = Instantiate(pickupFX, transform.position, Quaternion.identity);
                fx.Play();
                Destroy(fx.gameObject, 2f);
            }
            if (sfxSource != null && pickupClip != null)
                AudioSource.PlayClipAtPoint(pickupClip, transform.position);

            gameObject.SetActive(false);
        }
    }
}
