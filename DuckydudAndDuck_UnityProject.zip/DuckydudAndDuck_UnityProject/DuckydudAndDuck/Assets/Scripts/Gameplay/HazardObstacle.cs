using UnityEngine;

namespace DuckydudAndDuck.Gameplay
{
    /// <summary>
    /// General-purpose hazard: spins in place, sweeps back and forth, or
    /// moves along waypoints (reuses MovingPlatform's waypoint pattern) and
    /// knocks the player back with an impact FX/sound on contact.
    /// Use for swinging logs, sweeping arms, patrolling hazards, etc.
    /// </summary>
    public class HazardObstacle : MonoBehaviour
    {
        public enum HazardType { Spin, Sweep, Patrol }

        [Header("Behavior")]
        public HazardType hazardType = HazardType.Spin;
        public Vector3 rotationAxis = Vector3.up;
        public float speed = 90f;
        public float sweepAngle = 60f;

        [Header("Patrol (used if hazardType = Patrol)")]
        public Transform[] patrolPoints;

        [Header("Impact")]
        public float knockbackForce = 14f;
        public float knockbackUpwardBoost = 5f;
        public ParticleSystem impactFX;
        public AudioSource sfxSource;
        public AudioClip impactClip;

        private float _sweepTimer;
        private Quaternion _startRotation;
        private int _patrolIndex;

        private void Awake()
        {
            _startRotation = transform.rotation;
        }

        private void Update()
        {
            switch (hazardType)
            {
                case HazardType.Spin:
                    transform.Rotate(rotationAxis.normalized, speed * Time.deltaTime, Space.Self);
                    break;

                case HazardType.Sweep:
                    _sweepTimer += Time.deltaTime * speed * 0.01f;
                    float angle = Mathf.Sin(_sweepTimer) * sweepAngle;
                    transform.rotation = _startRotation * Quaternion.AngleAxis(angle, rotationAxis.normalized);
                    break;

                case HazardType.Patrol:
                    if (patrolPoints != null && patrolPoints.Length > 0)
                    {
                        Transform target = patrolPoints[_patrolIndex];
                        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * 0.02f * Time.deltaTime);
                        if (Vector3.Distance(transform.position, target.position) < 0.05f)
                            _patrolIndex = (_patrolIndex + 1) % patrolPoints.Length;
                    }
                    break;
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.TryGetComponent(out DuckydudAndDuck.Player.PlayerController player))
            {
                Vector3 dir = other.transform.position - transform.position;
                dir.y = 0.2f;
                player.ApplyKnockback(dir.normalized, knockbackForce, knockbackUpwardBoost);
                if (impactFX != null) impactFX.Play();
                if (sfxSource != null && impactClip != null) sfxSource.PlayOneShot(impactClip);
            }
        }
    }
}
