using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace DuckydudAndDuck.UI
{
    /// <summary>
    /// Optional: put this on a persistent "Boot" scene loaded first, or call
    /// LoadSceneWithLoadingScreen from GameManager instead of SceneManager
    /// directly if you want a visible loading bar (recommended for WebGL,
    /// where first-time asset downloads can take a few seconds).
    /// </summary>
    public class LoadingScreen : MonoBehaviour
    {
        public static LoadingScreen Instance { get; private set; }

        public GameObject panel;
        public Image progressBarFill;

        private void Awake()
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            if (panel != null) panel.SetActive(false);
        }

        public void LoadScene(string sceneName)
        {
            StartCoroutine(LoadRoutine(sceneName));
        }

        private IEnumerator LoadRoutine(string sceneName)
        {
            if (panel != null) panel.SetActive(true);
            AsyncOperation op = SceneManager.LoadSceneAsync(sceneName);
            op.allowSceneActivation = false;

            while (op.progress < 0.9f)
            {
                if (progressBarFill != null) progressBarFill.fillAmount = op.progress / 0.9f;
                yield return null;
            }

            if (progressBarFill != null) progressBarFill.fillAmount = 1f;
            yield return new WaitForSeconds(0.25f); // brief hold so the bar visibly completes
            op.allowSceneActivation = true;

            if (panel != null) panel.SetActive(false);
        }
    }
}
