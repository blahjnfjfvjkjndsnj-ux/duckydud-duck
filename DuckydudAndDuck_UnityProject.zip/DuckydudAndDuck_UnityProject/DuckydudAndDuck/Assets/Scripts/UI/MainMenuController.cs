using UnityEngine;
using UnityEngine.UI;

namespace DuckydudAndDuck.UI
{
    /// <summary>
    /// Drives the Main Menu scene: Play, Level Select, Challenges, Settings, Quit.
    /// </summary>
    public class MainMenuController : MonoBehaviour
    {
        [Header("Panels")]
        public GameObject rootMenuPanel;
        public GameObject levelSelectPanel;
        public GameObject settingsPanel;

        [Header("Root Buttons")]
        public Button playButton;
        public Button levelSelectButton;
        public Button challengesButton;
        public Button settingsButton;
        public Button quitButton;

        [Header("Level Select")]
        public LevelSelectButton[] levelButtons; // sized to match GameManager.levelSceneNames
        public Button levelSelectBackButton;

        [Header("Settings")]
        public Slider sfxSlider;
        public Slider musicSlider;
        public Button settingsBackButton;

        private void Start()
        {
            playButton?.onClick.AddListener(() => Managers.GameManager.Instance.LoadLevel(0));
            levelSelectButton?.onClick.AddListener(OpenLevelSelect);
            challengesButton?.onClick.AddListener(OpenLevelSelect); // Challenge mode reuses level select in this vertical slice
            settingsButton?.onClick.AddListener(OpenSettings);
            quitButton?.onClick.AddListener(() => Managers.GameManager.Instance.QuitGame());
            levelSelectBackButton?.onClick.AddListener(ShowRootMenu);
            settingsBackButton?.onClick.AddListener(ShowRootMenu);

            if (sfxSlider != null)
            {
                sfxSlider.value = Managers.GameManager.Instance.SfxVolume;
                sfxSlider.onValueChanged.AddListener(v => Managers.GameManager.Instance.SfxVolume = v);
            }
            if (musicSlider != null)
            {
                musicSlider.value = Managers.GameManager.Instance.MusicVolume;
                musicSlider.onValueChanged.AddListener(v => Managers.GameManager.Instance.MusicVolume = v);
            }

            RefreshLevelButtons();
            ShowRootMenu();
        }

        private void RefreshLevelButtons()
        {
            if (levelButtons == null) return;
            for (int i = 0; i < levelButtons.Length; i++)
            {
                bool unlocked = Managers.GameManager.Instance.IsLevelUnlocked(i);
                levelButtons[i].Setup(i, unlocked);
            }
        }

        private void ShowRootMenu()
        {
            rootMenuPanel?.SetActive(true);
            levelSelectPanel?.SetActive(false);
            settingsPanel?.SetActive(false);
        }

        private void OpenLevelSelect()
        {
            rootMenuPanel?.SetActive(false);
            levelSelectPanel?.SetActive(true);
            settingsPanel?.SetActive(false);
        }

        private void OpenSettings()
        {
            rootMenuPanel?.SetActive(false);
            levelSelectPanel?.SetActive(false);
            settingsPanel?.SetActive(true);
        }
    }
}
