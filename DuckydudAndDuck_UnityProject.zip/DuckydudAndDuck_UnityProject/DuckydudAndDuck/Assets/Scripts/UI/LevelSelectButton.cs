using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace DuckydudAndDuck.UI
{
    /// <summary>
    /// Attach to each level-select button. Shows a lock overlay when the
    /// level isn't unlocked yet, and loads the level (plus shows best time)
    /// when clicked and unlocked.
    /// </summary>
    public class LevelSelectButton : MonoBehaviour
    {
        public Button button;
        public GameObject lockIcon;
        public TMP_Text levelNameText;
        public TMP_Text bestTimeText;

        private int _levelIndex;

        public void Setup(int levelIndex, bool unlocked)
        {
            _levelIndex = levelIndex;
            if (button != null)
            {
                button.interactable = unlocked;
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(() => Managers.GameManager.Instance.LoadLevel(_levelIndex));
            }
            if (lockIcon != null) lockIcon.SetActive(!unlocked);

            if (unlocked && bestTimeText != null)
            {
                float best = Managers.GameManager.Instance.GetBestTime(_levelIndex);
                bestTimeText.text = best > 0 ? $"Best: {best:0.0}s" : "Not completed";
            }
        }
    }
}
