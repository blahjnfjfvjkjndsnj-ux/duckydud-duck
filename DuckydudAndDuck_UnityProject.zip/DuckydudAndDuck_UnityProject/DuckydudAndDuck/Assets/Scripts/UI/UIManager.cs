using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace DuckydudAndDuck.UI
{
    /// <summary>
    /// Wires up the in-level UI: HUD (collectible counter, timer), pause menu,
    /// and level-complete screen. Assign all fields in the Inspector after
    /// building the Canvas hierarchy described in SETUP_GUIDE.md.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        [Header("HUD")]
        public GameObject hudPanel;
        public TMP_Text collectibleCounterText;
        public TMP_Text timerText;

        [Header("Pause Menu")]
        public GameObject pausePanel;
        public Button resumeButton;
        public Button restartButton;
        public Button pauseQuitToMenuButton;

        [Header("Level Complete")]
        public GameObject levelCompletePanel;
        public TMP_Text finalTimeText;
        public TMP_Text finalCollectiblesText;
        public Button nextLevelButton;
        public Button replayButton;
        public Button completeQuitToMenuButton;

        private void Awake()
        {
            resumeButton?.onClick.AddListener(() => Managers.LevelManager.Instance.TogglePause());
            restartButton?.onClick.AddListener(() => { Time.timeScale = 1f; Managers.GameManager.Instance.ReloadCurrentLevel(); });
            pauseQuitToMenuButton?.onClick.AddListener(() => { Time.timeScale = 1f; Managers.GameManager.Instance.LoadMainMenu(); });

            nextLevelButton?.onClick.AddListener(OnNextLevelPressed);
            replayButton?.onClick.AddListener(() => Managers.GameManager.Instance.ReloadCurrentLevel());
            completeQuitToMenuButton?.onClick.AddListener(() => Managers.GameManager.Instance.LoadMainMenu());
        }

        public void ShowHUD()
        {
            if (hudPanel != null) hudPanel.SetActive(true);
            if (pausePanel != null) pausePanel.SetActive(false);
            if (levelCompletePanel != null) levelCompletePanel.SetActive(false);
        }

        public void UpdateCollectibleCounter(int found, int total)
        {
            if (collectibleCounterText != null)
                collectibleCounterText.text = $"Feathers: {found} / {total}";
        }

        public void UpdateTimer(float seconds)
        {
            if (timerText == null) return;
            int m = Mathf.FloorToInt(seconds / 60f);
            float s = seconds % 60f;
            timerText.text = $"{m:00}:{s:00.0}";
        }

        public void ShowPauseMenu()
        {
            if (pausePanel != null) pausePanel.SetActive(true);
        }

        public void HidePauseMenu()
        {
            if (pausePanel != null) pausePanel.SetActive(false);
        }

        public void ShowLevelComplete(float time, int collected, int total)
        {
            if (hudPanel != null) hudPanel.SetActive(false);
            if (levelCompletePanel != null) levelCompletePanel.SetActive(true);

            int m = Mathf.FloorToInt(time / 60f);
            float s = time % 60f;
            if (finalTimeText != null) finalTimeText.text = $"Time: {m:00}:{s:00.0}";
            if (finalCollectiblesText != null) finalCollectiblesText.text = $"Feathers: {collected} / {total}";

            bool hasNext = Managers.LevelManager.Instance.levelIndex + 1 < Managers.GameManager.Instance.levelSceneNames.Length;
            if (nextLevelButton != null) nextLevelButton.interactable = hasNext;
        }

        private void OnNextLevelPressed()
        {
            int next = Managers.LevelManager.Instance.levelIndex + 1;
            Managers.GameManager.Instance.LoadLevel(next);
        }
    }
}
