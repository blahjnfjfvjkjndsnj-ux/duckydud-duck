using UnityEngine;

namespace DuckydudAndDuck.Player
{
    /// <summary>
    /// Lightweight keybind remapping that works in WebGL builds without any
    /// external input package. Stores chosen KeyCodes in PlayerPrefs and
    /// exposes them as static getters. Wire a "press any key" UI to
    /// StartListening/the OnGUI capture below, or extend with your own UI.
    ///
    /// NOTE: For simplicity PlayerController currently reads Input.GetAxisRaw
    /// ("Horizontal"/"Vertical") for movement, which already maps to WASD and
    /// arrow keys by default in Unity's Input Manager (Edit > Project Settings
    /// > Input Manager) - no code changes needed for that part. This helper
    /// covers the single-key actions (Jump, Sprint, Pause) that benefit most
    /// from player-facing remapping.
    /// </summary>
    public static class InputRemapHelper
    {
        private const string KeyJump = "DD_Key_Jump";
        private const string KeySprint = "DD_Key_Sprint";
        private const string KeyPause = "DD_Key_Pause";

        public static KeyCode JumpKey
        {
            get => (KeyCode)PlayerPrefs.GetInt(KeyJump, (int)KeyCode.Space);
            set { PlayerPrefs.SetInt(KeyJump, (int)value); PlayerPrefs.Save(); }
        }

        public static KeyCode SprintKey
        {
            get => (KeyCode)PlayerPrefs.GetInt(KeySprint, (int)KeyCode.LeftShift);
            set { PlayerPrefs.SetInt(KeySprint, (int)value); PlayerPrefs.Save(); }
        }

        public static KeyCode PauseKey
        {
            get => (KeyCode)PlayerPrefs.GetInt(KeyPause, (int)KeyCode.Escape);
            set { PlayerPrefs.SetInt(KeyPause, (int)value); PlayerPrefs.Save(); }
        }

        public static void ResetToDefaults()
        {
            PlayerPrefs.DeleteKey(KeyJump);
            PlayerPrefs.DeleteKey(KeySprint);
            PlayerPrefs.DeleteKey(KeyPause);
        }
    }
}
