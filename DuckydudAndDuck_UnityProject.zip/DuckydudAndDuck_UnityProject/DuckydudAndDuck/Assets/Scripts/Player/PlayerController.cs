using UnityEngine;

namespace DuckydudAndDuck.Player
{
    /// <summary>
    /// Core physics-based movement for Ducky.
    /// Handles running, jumping, air control, ground detection, knockback,
    /// squash-and-stretch, and basic slope handling.
    /// Attach to the Ducky prefab root. Requires a CharacterController component.
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        public float walkSpeed = 6f;
        public float sprintSpeed = 9.5f;
        public float acceleration = 12f;
        public float airControlMultiplier = 0.5f;
        public float rotationSpeed = 12f;

        [Header("Jumping")]
        public float jumpHeight = 2.2f;
        public float gravity = -25f;
        public float fallGravityMultiplier = 1.6f;
        public float lowJumpGravityMultiplier = 2.2f;
        public int maxAirJumps = 0; // set to 1 for a double-jump feel
        public float coyoteTime = 0.12f;
        public float jumpBufferTime = 0.12f;

        [Header("Ground Check")]
        public LayerMask groundMask;
        public float groundCheckDistance = 0.25f;

        [Header("Squash & Stretch")]
        public Transform visualRoot; // child mesh transform, NOT the CharacterController root
        public float squashAmount = 0.25f;
        public float squashSpeed = 8f;

        [Header("Knockback")]
        public float knockbackDrag = 4f;

        [Header("Audio & FX")]
        public AudioSource sfxSource;
        public AudioClip jumpClip;
        public AudioClip landClip;
        public ParticleSystem landDustFX;
        public ParticleSystem runDustFX;

        private CharacterController _cc;
        private Vector3 _velocity;
        private Vector3 _horizontalVelocity;
        private Vector3 _knockbackVelocity;
        private float _coyoteTimer;
        private float _jumpBufferTimer;
        private int _airJumpsUsed;
        private bool _wasGrounded;
        private bool _isSprinting;
        private Vector3 _targetSquash = Vector3.one;
        private Animator _animator;

        public bool IsGrounded { get; private set; }
        public Vector3 PlanarVelocity => _horizontalVelocity;

        private static readonly int AnimSpeed = Animator.StringToHash("Speed");
        private static readonly int AnimGrounded = Animator.StringToHash("Grounded");
        private static readonly int AnimJumpTrigger = Animator.StringToHash("Jump");
        private static readonly int AnimVerticalVel = Animator.StringToHash("VerticalVelocity");

        private void Awake()
        {
            _cc = GetComponent<CharacterController>();
            _animator = GetComponentInChildren<Animator>();
            if (visualRoot == null && transform.childCount > 0)
                visualRoot = transform.GetChild(0);
        }

        private void Update()
        {
            GroundCheck();
            ReadInput();
            HandleJumpBuffering();
            ApplyGravity();
            Move();
            ApplySquashStretch();
            UpdateAnimator();
            _wasGrounded = IsGrounded;
        }

        private void GroundCheck()
        {
            IsGrounded = Physics.SphereCast(
                transform.position + Vector3.up * 0.3f,
                _cc.radius * 0.9f,
                Vector3.down,
                out RaycastHit hit,
                0.3f + groundCheckDistance,
                groundMask,
                QueryTriggerInteraction.Ignore);

            if (IsGrounded)
            {
                _coyoteTimer = coyoteTime;
                _airJumpsUsed = 0;
                if (!_wasGrounded && _velocity.y < -2f)
                {
                    OnLand();
                }
            }
            else
            {
                _coyoteTimer -= Time.deltaTime;
            }
        }

        private void ReadInput()
        {
            float h = Input.GetAxisRaw("Horizontal");
            float v = Input.GetAxisRaw("Vertical");
            _isSprinting = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);

            Transform cam = UnityEngine.Camera.main != null ? UnityEngine.Camera.main.transform : transform;
            Vector3 camForward = Vector3.ProjectOnPlane(cam.forward, Vector3.up).normalized;
            Vector3 camRight = Vector3.ProjectOnPlane(cam.right, Vector3.up).normalized;

            Vector3 wishDir = (camForward * v + camRight * h);
            if (wishDir.sqrMagnitude > 1f) wishDir.Normalize();

            float targetSpeed = (_isSprinting ? sprintSpeed : walkSpeed) * wishDir.magnitude;
            Vector3 targetVelocity = wishDir * targetSpeed;

            float accel = acceleration * (IsGrounded ? 1f : airControlMultiplier);
            _horizontalVelocity = Vector3.MoveTowards(_horizontalVelocity, targetVelocity, accel * Time.deltaTime * 10f);

            if (wishDir.sqrMagnitude > 0.01f)
            {
                Quaternion targetRot = Quaternion.LookRotation(wishDir, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
            }

            if (runDustFX != null)
            {
                bool shouldEmit = IsGrounded && wishDir.sqrMagnitude > 0.1f;
                var emission = runDustFX.emission;
                emission.enabled = shouldEmit;
            }
        }

        private void HandleJumpBuffering()
        {
            if (Input.GetButtonDown("Jump") || Input.GetKeyDown(KeyCode.Space))
            {
                _jumpBufferTimer = jumpBufferTime;
            }
            else
            {
                _jumpBufferTimer -= Time.deltaTime;
            }

            bool canGroundJump = _coyoteTimer > 0f;
            bool canAirJump = !canGroundJump && _airJumpsUsed < maxAirJumps;

            if (_jumpBufferTimer > 0f && (canGroundJump || canAirJump))
            {
                DoJump();
                _jumpBufferTimer = 0f;
                _coyoteTimer = 0f;
                if (canAirJump) _airJumpsUsed++;
            }
        }

        private void DoJump()
        {
            _velocity.y = Mathf.Sqrt(2f * -gravity * jumpHeight);
            _targetSquash = new Vector3(1f - squashAmount, 1f + squashAmount, 1f - squashAmount);
            if (sfxSource != null && jumpClip != null) sfxSource.PlayOneShot(jumpClip);
            _animator?.SetTrigger(AnimJumpTrigger);
        }

        private void OnLand()
        {
            _targetSquash = new Vector3(1f + squashAmount, 1f - squashAmount, 1f + squashAmount);
            if (sfxSource != null && landClip != null) sfxSource.PlayOneShot(landClip);
            if (landDustFX != null) landDustFX.Play();
        }

        private void ApplyGravity()
        {
            float g = gravity;
            if (_velocity.y < 0f)
                g *= fallGravityMultiplier;
            else if (_velocity.y > 0f && !(Input.GetButton("Jump") || Input.GetKey(KeyCode.Space)))
                g *= lowJumpGravityMultiplier;

            _velocity.y += g * Time.deltaTime;
            if (IsGrounded && _velocity.y < 0f)
                _velocity.y = -2f; // keeps the controller grounded on slopes
        }

        private void Move()
        {
            // Knockback decays over time and is applied on top of normal movement
            _knockbackVelocity = Vector3.MoveTowards(_knockbackVelocity, Vector3.zero, knockbackDrag * Time.deltaTime);

            Vector3 fullVelocity = _horizontalVelocity + new Vector3(0f, _velocity.y, 0f) + _knockbackVelocity;
            _cc.Move(fullVelocity * Time.deltaTime);
        }

        private void ApplySquashStretch()
        {
            if (visualRoot == null) return;
            visualRoot.localScale = Vector3.Lerp(visualRoot.localScale, _targetSquash, squashSpeed * Time.deltaTime);
            _targetSquash = Vector3.Lerp(_targetSquash, Vector3.one, squashSpeed * 0.5f * Time.deltaTime);
        }

        private void UpdateAnimator()
        {
            if (_animator == null) return;
            _animator.SetFloat(AnimSpeed, _horizontalVelocity.magnitude);
            _animator.SetBool(AnimGrounded, IsGrounded);
            _animator.SetFloat(AnimVerticalVel, _velocity.y);
        }

        /// <summary>Called by hazards/obstacles to push Ducky away and add a bit of vertical pop.</summary>
        public void ApplyKnockback(Vector3 direction, float force, float upwardBoost = 4f)
        {
            _knockbackVelocity = direction.normalized * force;
            _velocity.y = Mathf.Max(_velocity.y, upwardBoost);
            _targetSquash = new Vector3(1.3f, 0.7f, 1.3f);
        }

        /// <summary>Used by bounce pads to launch the player.</summary>
        public void ApplyBounce(float upwardVelocity)
        {
            _velocity.y = upwardVelocity;
            _targetSquash = new Vector3(0.6f, 1.5f, 0.6f);
        }

        /// <summary>Teleports the player (checkpoint respawn) and resets velocity.</summary>
        public void Teleport(Vector3 position, Quaternion rotation)
        {
            _cc.enabled = false;
            transform.position = position;
            transform.rotation = rotation;
            _velocity = Vector3.zero;
            _horizontalVelocity = Vector3.zero;
            _knockbackVelocity = Vector3.zero;
            _cc.enabled = true;
        }

        private void OnControllerColliderHit(ControllerColliderHit hit)
        {
            // Allows moving platforms to carry the player - see MovingPlatform.cs for the pairing logic.
            if (hit.gameObject.TryGetComponent(out Platforms.PlatformPassenger passenger))
            {
                passenger.NotifyStandingOn(this);
            }
        }
    }
}
