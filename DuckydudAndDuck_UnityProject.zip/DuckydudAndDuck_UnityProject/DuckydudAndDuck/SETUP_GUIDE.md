# Duckydud & Duck — Unity Project Setup Guide

## Why this guide exists

I built this as a **real Unity project** with all gameplay scripts written and working
(player physics, camera, moving/rotating/falling platforms, bounce pads, hazards,
checkpoints, collectibles, finish line, menus, pause, level-complete, save data,
per-level music). What I could **not** do from here is run the Unity Editor itself —
that requires a licensed, GPU-backed desktop install, which this environment doesn't
have. So the last step — dragging these scripts onto GameObjects in a scene, and
pressing "Build" — needs to happen on your machine, in the free Unity Editor.

This guide walks that last step precisely so it goes fast. Budget **1–2 hours** for a
first pass with one working level; each additional level reuses the same pieces.

---

## 1. Install Unity

1. Install **Unity Hub**: https://unity.com/download
2. In Unity Hub, install **Unity 2022 LTS** (2022.3.x) — it has the most stable WebGL
   and Windows build pipelines.
3. When installing, make sure these **modules** are checked:
   - `WebGL Build Support`
   - `Windows Build Support (IL2CPP)` (or Mono — either works for Windows)

## 2. Open the project

1. In Unity Hub → **Add** → select the `DuckydudAndDuck` folder (the one containing
   `Assets/`, `ProjectSettings/`).
2. Open it with Unity 2022 LTS. Unity will import everything and generate the missing
   `Library/` cache automatically — this can take a few minutes the first time.

## 3. Install required packages (Package Manager)

Open **Window → Package Manager** and install:

- **TextMeshPro** (usually prompts automatically the first time you use a `TMP_Text` —
  click "Import TMP Essentials" when asked).
- **Cinemachine** — optional; the included `CameraFollow.cs` is a hand-rolled camera
  and does *not* require Cinemachine, but it's a nice upgrade path if you want it later.

## 4. Import the KayKit models

The KayKit assets are shipped as `.obj`/`.mtl` files under
`Assets/Art/Models/KayKit/`. Unity 2022 imports `.obj` natively — just click into that
folder in the Project window and Unity will generate mesh prefabs automatically.

**Recommended immediate step:** select `Assets/Art/Models/KayKit/Models/Characters/Duck`
in the Project window, drag `character_duck.obj` into a scene to confirm it renders
with its material. If materials look grey/pink, select the `.mtl`-linked material and
set its shader to **Universal Render Pipeline/Lit** if you're using URP, or
**Standard** if you're using Built-in RP.

> Tip: KayKit's duck is unrigged (no skeleton/animations) in this pack. `PlayerController`
> works fine without an Animator (it just won't play run/jump animation clips) — it
> still does full physics, squash-and-stretch, and knockback. If you want animated
> running/jumping, either rig the mesh yourself in Blender or swap in a rigged
> placeholder and keep KayKit's duck as the visual mesh once you've rigged it.

## 5. Import the Bit by Bit font

1. Select `Assets/Art/Fonts/BitByBit.ttf`.
2. Right-click it → **Create → TextMeshPro → Font Asset**. This generates the SDF font
   asset TMP needs.
3. Use that generated `BitByBit SDF` asset on every `TMP_Text` in your UI (title,
   buttons, HUD, counters) for the on-brand toy-cartoon look.

## 6. Scene setup — Main Menu

Create a scene named exactly **`MainMenu`** (`File → New Scene`, save as
`Assets/Scenes/MainMenu.unity`):

1. Add a Canvas (`GameObject → UI → Canvas`), set **Canvas Scaler → Scale With Screen
   Size**, reference resolution `1920x1080`.
2. Build panels: `RootMenuPanel` (Play / Level Select / Challenges / Settings / Quit
   buttons), `LevelSelectPanel` (one `LevelSelectButton`-scripted button per level),
   `SettingsPanel` (SFX slider, Music slider, Back button).
3. Add an empty GameObject `MenuController`, attach `MainMenuController.cs`, drag all
   the panel/button references into its Inspector fields.
4. Add an empty GameObject `GameManagerObject`, attach `GameManager.cs`. This object
   must exist in the **first scene that ever loads** — it marks itself
   `DontDestroyOnLoad` so it survives into every level.
5. Put Ducky and Duck models in the background of the menu, animated slowly (simple
   `transform.Rotate` script or an Animator idle loop) for personality, per the brief.

## 7. Scene setup — one full level (repeat per level)

Name scenes exactly as listed in `GameManager.levelSceneNames`:
`Level01_DuckDash`, `Level02_WackyWarehouse`, `Level03_SkyDuck`,
`Level04_TopsyTurvyFactory`, `Level05_DuckArena`, `Level06_FinalFlight`.

For each level:

1. **Ground/geometry**: build the course from KayKit's barrier/platform/detail meshes
   (`Assets/Art/Models/KayKit/Models/obj/`). Add `MeshCollider` (or simplified `BoxCollider`s
   for performance) to static geometry, mark it as **Static** in the Inspector for
   Unity's occlusion/batching optimizations.
2. **Ducky (player)**:
   - Create an empty GameObject `Ducky`, add `CharacterController` (radius ~0.4,
     height ~1.2) and `PlayerController.cs`.
   - Child the `character_duck` mesh under `Ducky`; assign that child to
     `PlayerController.visualRoot`.
   - Set `groundMask` to a new "Ground" layer applied to all level geometry.
3. **Camera**: on the Main Camera, attach `CameraFollow.cs`, set `target` to `Ducky`,
   set `obstructionMask` to the "Ground" layer.
4. **Moving platforms**: empty GameObject with the platform mesh as a child, add
   `PlatformPassenger.cs` + `MovingPlatform.cs`, and place empty `Transform` waypoints
   as children of the level root, assigned in order to the `waypoints` array.
5. **Rotating platforms/obstacles**: same pattern with `RotatingPlatform.cs`
   (`isObstacle = true` for spinning hazards, `false` for rideable turntables).
6. **Falling platforms**: `PlatformPassenger.cs` + `FallingPlatform.cs`, `Rigidbody`
   auto-added if missing.
7. **Bounce pads**: a trigger `BoxCollider`/`SphereCollider` (Is Trigger ✓) with
   `BouncePad.cs`, `visualMesh` pointing at the pad's squash mesh.
8. **Hazards** (spinning, sweeping, patrolling): `HazardObstacle.cs` on a trigger
   collider.
9. **Checkpoints**: trigger volume + `Checkpoint.cs`, `respawnPoint` a child Transform
   just above the platform.
10. **Collectibles**: trigger volume + `Collectible.cs` scattered through the level,
    including a few off the main path for the brief's "secret areas."
11. **Finish line**: trigger volume + `FinishLine.cs` at the end.
12. **Kill zone**: one big flat trigger `BoxCollider` well below the whole level +
    `KillZone.cs`, so falling off respawns you instead of falling forever.
13. **Level Manager**: empty GameObject `LevelManagerObject`, attach `LevelManager.cs`.
    Set `levelIndex` (0 for Duck Dash, 1 for Wacky Warehouse, etc. — must match the
    index in `GameManager.levelSceneNames`), `totalCollectiblesInLevel`, drag in
    `player` and `playerSpawnPoint`.
14. **HUD/Pause/Complete UI**: same Canvas pattern as the main menu — build the panels
    described in `UIManager.cs`'s fields, attach `UIManager.cs` to a `UIManagerObject`,
    wire it into `LevelManager.uiManager`.
15. **Music**: empty GameObject with `AudioSource` + `MusicManager.cs`, drop in that
    level's track.

Once **Level01_DuckDash** is fully wired this way, duplicate the scene for the other
five and re-skin/re-layout geometry — the scripts don't change per level, only the
placement of objects and which KayKit meshes you use.

## 8. Add scenes to Build Settings

`File → Build Settings` → **Add Open Scenes** for `MainMenu` and each level, in this
exact order (index 0 = MainMenu):

```
0: MainMenu
1: Level01_DuckDash
2: Level02_WackyWarehouse
3: Level03_SkyDuck
4: Level04_TopsyTurvyFactory
5: Level05_DuckArena
6: Level06_FinalFlight
```

---

## 9. Build for Windows (.exe)

1. `File → Build Settings` → select **PC, Mac & Linux Standalone**, target **Windows**,
   architecture **x86_64**.
2. Click **Build**, choose an output folder (e.g. `Builds/Windows/`).
3. Unity produces `DuckydudAndDuck.exe` plus a `DuckydudAndDuck_Data` folder and
   supporting DLLs — **zip the whole output folder together**. That zip is what you
   hand to someone else; they extract and double-click the `.exe`, no installs needed.

## 10. Build for the browser and publish to itch.io (WebGL)

1. `File → Build Settings` → select **WebGL** → **Switch Platform** (first time takes
   a few minutes to recompile).
2. `Player Settings` (still in Build Settings window) → **Publishing Settings**:
   - **Compression Format**: set to **Disabled** (simplest for itch.io — Gzip/Brotli
     need extra web server config that itch.io's static hosting doesn't always set up
     correctly out of the box; Disabled avoids that headache for a first upload).
3. Click **Build**, choose an output folder (e.g. `Builds/WebGL/`).
4. **Zip the *contents* of that output folder** (the `index.html`, `Build/`, and
   `TemplateData/` folders themselves — not a parent folder containing them).
5. On itch.io:
   - Create a new project → **Kind of project: HTML**.
   - Upload the zip you just made.
   - Check **"This file will be played in the browser"** next to the uploaded zip.
   - Set the embed viewport to your Player Settings resolution (e.g. 1920x1080, or
     enable "Fullscreen button").
   - Save & view page — itch.io will host and stream the WebGL build directly.

**Known WebGL caveats worth knowing up front:**
- `Application.Quit()` (used by the Quit button) is automatically a no-op in WebGL —
  that's expected and fine; it just won't do anything when played in-browser.
- Player Settings → **Other Settings → Configuration**: keep IL2CPP + WebAssembly
  (default) for WebGL — required, already the default in 2022 LTS.
- First load can take 10–30 seconds depending on total asset size — the `LoadingScreen.cs`
  script + itch.io's own loading bar cover that.
- Keep texture sizes reasonable (KayKit's are already lightweight) to keep the WebGL
  build small — itch.io has no hard size limit but smaller loads faster for players.

---

## 11. Testing checklist before you call it done

- [ ] Play from `MainMenu` → Play → completes Level 1 → returns to menu or advances.
- [ ] Pause (Esc) works mid-level and Resume/Restart/Quit-to-menu all work.
- [ ] Falling off the level respawns at the last checkpoint, not the level start.
- [ ] Collectible counter updates and persists to the level-complete screen.
- [ ] Second level is locked in Level Select until first is completed.
- [ ] WebGL build actually loads and is playable in a browser tab, not just the Editor.
- [ ] Windows build folder, when zipped and re-extracted somewhere else, launches
      correctly (this catches any accidental absolute-path references).

---

## What's already done vs. what's left to you

**Done (in this repo):** every gameplay/physics/camera/UI/save script described in the
original brief, fully commented, referencing your KayKit and Bit by Bit assets.

**Left to you (Editor-only work, no coding required):** placing objects in scenes,
wiring Inspector references, and pressing the Build button per the steps above. This
is normal Unity workflow — code can't do it from outside the Editor.

If you get stuck on any specific step (a wiring error, a missing reference, a build
error message), copy the exact error text back to me and I'll debug it with you.
